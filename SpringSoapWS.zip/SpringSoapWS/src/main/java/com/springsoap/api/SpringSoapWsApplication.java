package com.springsoap.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSoapWsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSoapWsApplication.class, args);
	}

}
